package br.com.hackaton2023.repository;

import br.com.hackaton2023.model.TransacaoPix;
import org.springframework.data.repository.CrudRepository;

public interface TransacaoPixRepository extends CrudRepository<TransacaoPix, Long> {
}
