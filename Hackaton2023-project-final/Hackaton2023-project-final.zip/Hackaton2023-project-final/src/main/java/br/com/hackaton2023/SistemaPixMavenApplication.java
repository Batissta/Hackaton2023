package br.com.hackaton2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaPixMavenApplication {

    public static void main(String[] args) {
        SpringApplication.run(SistemaPixMavenApplication.class, args);
    }

}
