package br.com.hackaton2023.SistemaPix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaPixApplicationTests {

	@Test
	void contextLoads() {
	}

}
