package br.com.hackaton2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaPixMavenApplicationTests {

    @Test
    void contextLoads() {
    }

}
